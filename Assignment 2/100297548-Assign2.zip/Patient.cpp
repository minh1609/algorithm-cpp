#include "Patient.h"

Patient::Patient(string id, int priority) {
    this->id = id;
    this->priority = priority;
}
